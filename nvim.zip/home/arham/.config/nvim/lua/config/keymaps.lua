-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here

-- Automatically save and run code based on the current filetype

vim.keymap.set("n", "<C-M-t>", function()
  vim.cmd("write")
  local file = vim.fn.shellescape(vim.fn.expand("%:p"))
  local cmds = {
    python = "python3 " .. file,
    javascript = "node " .. file,
    typescript = "npx tsx " .. file,
    lua = "lua " .. file,
    sh = "bash " .. file,
    go = "go run " .. file,
    rust = "cargo run",
    c = "gcc " .. file .. " -o /tmp/a.out && /tmp/a.out",
    cpp = "g++ " .. file .. " -o /tmp/a.out && /tmp/a.out",
  }
  local cmd = cmds[vim.bo.filetype]
  if not cmd then
    vim.notify("No run command for filetype: " .. vim.bo.filetype, vim.log.levels.WARN)
    return
  end

  -- Keep the process alive until a key is pressed, then it exits and the
  -- float auto-closes, so the "[Process exited 0]" line never shows up.
  local wrapped = cmd .. '; printf "\\n\\n[press any key to close]"; read -n 1 -s -r'

  Snacks.terminal({ "bash", "-c", wrapped }, {
    cwd = vim.fn.expand("%:p:h"),
    win = {
      position = "float",
      border = "rounded",
      width = 0.8,
      height = 0.8,
    },
  })
end, { desc = "Run current file" })
